<?php require('connection.php');?>

<html lang="en">
 <head>
  <title>Save Doctor</title>
 <link rel="stylesheet" href="css/bootstrap.css"/>
 </head> 
 <body>
<table class="table table-bordered">

<tr bgcolor=blue><td align=center><font SIZE=6 color=white>HOSPITAL
MANAGEMENT SYSTEM</font></td></tr>
<tr><td><table align=center width=750 cellspacing=0 cellpadding=5>
<tr><td align=center><a href=doctors_list.php>Doctors</td><td align=center><a
href=patients_list.php>Patients</td><td align=center><a
href=appointment_list.php>Appointments</td>
</table></td></tr>
<tr bgcolor=red><td ><font size=4 color=white>Save
Patient</font></td></tr>
<?php

$name=trim($_POST["name"]);
$sex=trim($_POST["sex"]);
$addr=trim($_POST["addr"]);
$age=trim($_POST["age"]);
$sick=trim($_POST["sick"]);
$error=0;
if ($name=="") { $error=1; echo "<tr><td><font color=red size=4>Name
can't empty</font></td></tr>"; 
}
if ($sex=="") { $error=1; echo "<tr><td><font color=red
size=4>Sex can't empty</font></td></tr>"; 
}
if ($addr=="") { $error=1; echo "<tr><td><font color=red
size=4>Address can't empty</font></td></tr>"; 
}
if ($age=="") { $error=1; echo "<tr><td><font color=red
    size=4>Address can't empty</font></td></tr>"; 
}
if ($sick=="") { $error=1; echo "<tr><td><font color=red
        size=4>Address can't empty</font></td></tr>"; 
}
if ($error==0) {
$con = mysqli_connect("localhost","sameer","sameerabc");
mysqli_select_db($con,"hospital");
mysqli_query($con,"INSERT into patient(pname,paddr,psex,page,psickness,pshow) values ('$name','$addr','$sex','$age','$sick','Y')");
echo "<tr><td align=center><font size=4 color=green>Patient data recorded.</font></td></tr>";
}
else {
 echo "<form name=fdadd method=post action=save_pat.php>";
 echo "<tr><td><table width=750 cellspacing=0 cellpadding=5>";
 echo "<tr><td>Doctor Name</td><td><input type=text name=name
size=30 maxlength=30 value='".$name."'></td></tr>";
 echo "<tr><td>Sex</td><td><input type=text name=spec
size=30 maxlength=30 value='".$sex."'></td></tr>";
 echo "<tr><td>Sex</td><td><input type=text name=spec
size=30 maxlength=30 value='".$addr."'></td></tr>";
echo "<tr><td>Sex</td><td><input type=text name=spec
size=30 maxlength=30 value='".$age."'></td></tr>";
echo "<tr><td>Sex</td><td><input type=text name=spec
size=30 maxlength=30 value='".$sick."'></td></tr>";
 echo "</table></td></tr>";
 echo "<tr><td align=center><input type=submit
value=Submit></td></tr>";
 echo "</form>";
}
echo "<tr><td align=center><a
href=patients_list.php>Continue...</a></td></tr>";
echo "</table>";
echo "</body></html>";