<?php
error_reporting(1);
$rno=$_GET["rno"];
require('connection.php');
$con = mysqli_connect("localhost","sameer","sameerabc");
mysqli_select_db($con,"hospital");
mysqli_query($con,"update appt set ashow='Y' where ano='$rno'");
header('location:appointment_list.php');
?>