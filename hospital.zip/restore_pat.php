<?php require('connection.php');?>
<html lang="en">
 <head>
  <title>Recover Doctor</title>
 <link rel="stylesheet" href="css/bootstrap.css"/>
 </head> 
 <body>
<table class="table table-bordered">
<tr bgcolor=blue><td align=center><font SIZE=6 color=white>HOSPITAL
MANAGEMENT SYSTEM</font></td></tr>
<tr><td><table align=center width=750 cellspacing=0 cellpadding=5>
<tr><td align=center><a href=doctors_list.php>Doctors</td><td align=center><a
href=patients_list.php>Patients</td><td align=center><a
href=appointment_list.php>Appointments</td>
</table></td></tr>
<tr bgcolor=red><td ><font size=4 color=white>Recover
Patient</font></td></tr>
<?php

$rno=$_GET["rno"];
$con = mysqli_connect("localhost","sameer","sameerabc");
mysqli_select_db($con,"hospital");
mysqli_query($con,"update Patient set pshow='Y' where pno='$rno'");
echo "<tr><td align=center><font size=4 color=green>Record Recovered</font></td></tr>";
echo "<tr><td align=center><a
href=patients_list.php>Continue...</a></td></tr>";
echo "</table>";
echo "</body></html>"; 