<?php
error_reporting(1);
if(!mysqli_connect("localhost","sameer","sameerabc"))
 {
  echo "<tr><td><font color=red size=4>Connection
Error</font></td></tr>";
  die();
 }
 $con = mysqli_connect("localhost","sameer","sameerabc");
 mysqli_select_db($con,"hospital");
 
 extract($_POST);
 if(isset($signIn))
 {
//echo $user,$pass;
//for Admin
$que=mysqli_query($con,"INSERT into admin values ('$id','$Na',$user','$pass')");
echo "<script>window.location='index.php'</script>"; 
 }
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content=""> 
    <title>Hospital Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/signIn.css" rel="stylesheet">
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
  </head>
  <body>
    <div class="container">
      <form method="post" class="form-signin" action="">
        <h2 class="form-signin-heading">Please enter the details...</h2>
        <label><?php echo $err; ?></label>
        <label for="inputId" class="sr-only">ID Number</label>
        <input type="text" id="inputId" name="id" class="form-control" placeholder="Enter ID" required autofocus>
        <label for="inputNa" class="sr-only">ID Number</label>
        <input type="text" id="inputNa" name="Na" class="form-control" placeholder="Enter your name" required autofocus>
		<label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail" name="user" class="form-control" placeholder="Enter Email" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="pass" id="inputPassword" class="form-control" placeholder="password" required>
        To Login <?php "&nbsp" ?><a href="index.php">click here</a>
<button class="btn btn-lg btn-primary btn-block" name="signIn" type="submit">Submit</button>
      </form>
    </div> 
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
  <footer align="center">Developed by: Sameer ali khan A</footer>
  </html>