
<?php
session_start();
error_reporting(1);

if(!mysqli_connect("localhost","sameer","sameerabc"))
 {
  echo "<tr><td><font color=red size=4>Connection
Error (can't connect to the database)</font></td></tr>";
  die();
 }
$con = mysqli_connect("localhost","sameer","sameerabc");
 mysqli_select_db($con,"hospital");
 
if($_SESSION['admin']=="")
{
header('index.php');
}
?>
