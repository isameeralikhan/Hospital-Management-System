<?php
require('connection.php');
error_reporting(1);
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 30)) {
    header('location:logout.php');
}
$_SESSION['LAST_ACTIVITY'] = time();
?>
<html lang="en">
 <head>
  <title>Patients Lists</title>
 <link rel="stylesheet" href="css/bootstrap.css"/>
 <style>
  body{
    background-image: linear-gradient(green,white);
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
  }
  </style>
 </head> 
 <body>
<table class="table table-bordered">
<tr style="background-color:#33CC00;border:2px solid black;"><td align=center><img src="images2.png" style="float:left;height:80px;width:100px;"><font style="font-size:40px;color:white;font-family:serif;
font-weight:bold;">
HOSPITAL &nbsp;&nbsp; MANAGEMENT &nbsp;&nbsp; SYSTEM</font></td></tr>
<tr><td><h3 style="background:red;padding:20px;color:#FFFFFF;margin:0px;font-family:cursive;hover:color:red;">
	<span>Hello <?php echo $_SESSION['admin']?>!</span>
	<span style="float:right"><a style="color:#FFFFFF" href="logout.php">Logout</a></span>
</h3></td></tr>
<tr bgcolor=blue><td align=center><table align=center width=750 cellspacing=0 cellpadding=5>
<tr><td align=center><a href=doctors_list.php style="color:white;font-weight:bold;" onMouseOver="this.style.color='black'" onMouseOut="this.style.color='#FFF'">DOCTORS</td><td align=center>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=patients_list.php style="color:white;font-weight:bold;" onMouseOver="this.style.color='black'" onMouseOut="this.style.color='#FFF'">PATIENTS</td><td align=center>
<a href=appointment_list.php style="color:white;font-weight:bold;" onMouseOver="this.style.color='black'" onMouseOut="this.style.color='#FFF'">APPOINTMENTS</td></table></td></tr>
<tr bgcolor=red><td ><font size=4 color=white>Appointments
List</font></td></tr>
<tr><td><a href=add_pat.php style="color:red">Add New Record</a></td></tr>
<tr><td><table width=800 cellspacing=0 cellpadding=5>
<tr bgcolor=#ccccc><td align=center>S No</td><td align=center>Patient
Name</td><td align=center>Address</td><td align=center>sex</td><td></td><td align=center>&nbsp&nbsp Age</td>
<td align=center>sickness/issue</td><td align=center>Options</td></tr>
<?php
$con = mysqli_connect("localhost","sameer","sameerabc");
mysqli_select_db($con,"hospital");

$rs1=mysqli_query($con,"SELECT * from patient where pshow='Y' order by
pname;");
$sno=1;
while( $row=mysqli_fetch_array($rs1)) {
 echo "<tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp$sno</td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[1]</td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[2]</td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[3]</td><td>
 <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[4]</td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[5]</td><td>
 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href=modify_pat.php?rno=".$sno.">Modify</a> | 
 <a href=delete_pat.php?rno=".$sno." style='color:red'>Delete</a></td></tr>";
 $sno++;
}
if($sno==1){ echo "<tr><td align=center><font size=4 color=red>Records
Not Found</font></td></tr>";}
?>
</table></td></tr>
<tr><td align=center><hr></td></tr>
<tr bgcolor=red><td><font size=4 color=white>Deleted
Records</font></td></tr>
<tr><td><table width=550 cellspacing=0 cellpadding=5>
<tr bgcolor=#ccccc><td align=center>S No</td><td align=center>patient
Name</td><td align=center>Address</td><td
align=center>Options</td></tr>
<?php
$rs2=mysqli_query($con,"SELECT * from patient where pshow='N' order by
pname;");
$sno=1;
while( $row=mysqli_fetch_array($rs2)) {
 echo "<tr><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$sno</td><td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[1]</td><td>
 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$row[2]</td><td>
 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href=restore_pat.php?rno=".$row[0].">Restore</a></td></tr>";
 $sno++;
}
if($sno==1){ echo "<tr><td align=center><font size=4 color=red>Records
Not Found</font></td></tr>";}
?>
</table></td></tr>
</table>
</body>
<footer align="center" style="margin-top:150px;font-style:italic;color:red;">Developed by: Sameer ali khan A</footer>
</html> 