<?php
session_start();
error_reporting(1);
if(!mysqli_connect("localhost","sameer","sameerabc"))
 {
  echo "<tr><td><font color=red size=4>Connection
Error</font></td></tr>";
  die();
 }
 $con = mysqli_connect("localhost","sameer","sameerabc");
 mysqli_select_db($con,"hospital");
 
 extract($_POST);
 if(isset($signIn))
 {
	$que=mysqli_query($con,"SELECT name from admin where user='$user' and pass='$pass'");
	 $row= mysqli_num_rows($que);
   $row1=mysqli_fetch_array($que);
	 if($row)
	 {
		$_SESSION['admin']=$row1['name'];
		echo "<script>window.location='appointment_list.php'</script>";	 	
	 }
	 else
	 {
	  $err="<span class='glyphicon glyphicon-exclamation-sign' style='color:red'></span> <font color='red'>Invalid Login ID or password!</font>";
	 }
	
 
 }
if($_SESSION['admin']!="")
{
header('appointment_list.php');
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 10)) {
  header('location:logout.php');
}
$_SESSION['LAST_ACTIVITY'] = time();
 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content=""> 
    <title>Hospital Management System</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/signIn.css" rel="stylesheet">
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
  </head>
  <body>
    <div class="container">
      <form method="post" class="form-signin">
        <h2 class="form-signin-heading">Please Login</h2>
        <label><?php echo $err; ?></label>
		<label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" id="inputEmail" name="user" class="form-control" placeholder="Enter Email" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="pass" id="inputPassword" class="form-control" placeholder="password" required>
        Not a Registered user? <?php "&nbsp" ?><a href="add_user.php">click here</a>
<button class="btn btn-lg btn-primary btn-block" name="signIn" type="submit">Sign in</button>
      </form>
    </div> 
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
  <footer align="center">Developed by: Sameer ali khan A</footer>
</html>